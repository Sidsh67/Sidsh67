package com.model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import org.hibernate.query.criteria.internal.expression.function.AggregationFunction.COUNT;

@Entity
public class Department {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int dept_id;
	private String title;
	private String description;
	private String created_by;
	private String modified_by;
	private Date created_ae_time;
	private Date best_modified_time;
	public int getDept_id() {
		return dept_id;
	}
	public void setDept_id(int dept_id) {
		this.dept_id = dept_id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getCreated_by() {
		return created_by;
	}
	public void setCreated_by(String created_by) {
		this.created_by = created_by;
	}
	public String getModified_by() {
		return modified_by;
	}
	public void setModified_by(String modified_by) {
		this.modified_by = modified_by;
	}
	public Date getCreated_ae_time() {
		return created_ae_time;
	}
	public void setCreated_ae_time(Date created_ae_time) {
		this.created_ae_time = created_ae_time;
	}
	public Date getBest_modified_time() {
		return best_modified_time;
	}
	public void setBest_modified_time(Date best_modified_time) {
		this.best_modified_time = best_modified_time;
	}
	
	

	

}
