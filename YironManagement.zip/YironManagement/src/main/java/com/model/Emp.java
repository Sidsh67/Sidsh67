package com.model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Emp {
	@Id
	private String  aadhar_id;
	
	private String first_name;
	
	private String last_name;
	
	private String address;
	
	private long  pincode;
	
	private String created_by;
	
	private String modified_by;
	
	private String email_id;
	
	private String gender;
	
	private String age;
	
	private Department department;

	public String getAadhar_id() {
		return aadhar_id;
	}

	public void setAadhar_id(String aadhar_id) {
		this.aadhar_id = aadhar_id;
	}

	public String getFirst_name() {
		return first_name;
	}

	public void setFirst_name(String first_name) {
		this.first_name = first_name;
	}

	public String getLast_name() {
		return last_name;
	}

	public void setLast_name(String last_name) {
		this.last_name = last_name;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public long getPincode() {
		return pincode;
	}

	public void setPincode(long pincode) {
		this.pincode = pincode;
	}

	public String getCreated_by() {
		return created_by;
	}

	public void setCreated_by(String created_by) {
		this.created_by = created_by;
	}

	public String getModified_by() {
		return modified_by;
	}

	public void setModified_by(String modified_by) {
		this.modified_by = modified_by;
	}

	public String getEmail_id() {
		return email_id;
	}

	public void setEmail_id(String email_id) {
		this.email_id = email_id;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		gender = gender;
	}

	public String getAge() {
		return age;
	}

	public void setAge(String age) {
		this.age = age;
	}

	public Emp(String aadhar_id, String first_name, String last_name, String address, long pincode, String created_by,
			String modified_by, String email_id, String gender, String age) {
		super();
		this.aadhar_id = aadhar_id;
		this.first_name = first_name;
		this.last_name = last_name;
		this.address = address;
		this.pincode = pincode;
		this.created_by = created_by;
		this.modified_by = modified_by;
		this.email_id = email_id;
		gender = gender;
		this.age = age;
	}

	public Emp() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "Emp [aadhar_id=" + aadhar_id + ", first_name=" + first_name + ", last_name=" + last_name + ", address="
				+ address + ", pincode=" + pincode + ", created_by=" + created_by + ", modified_by=" + modified_by
				+ ", email_id=" + email_id + ", Gender=" + gender + ", age=" + age + "]";
	}
	

	
}
