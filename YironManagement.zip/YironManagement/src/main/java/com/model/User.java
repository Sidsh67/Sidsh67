package com.model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class User {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int user_id;
	
	private String user_name;
	
	private String password;
	
	private String status;
	
	private String created_by;
	
	private String modified_by;
	
	private Date created_ae_time;
	
	private Date last_modified_time;

	public int getUser_id() {
		return user_id;
	}

	public String getUser_name() {
		return user_name;
	}

	public void setUser_name(String user_name) {
		this.user_name = user_name;
	}

	public void setUser_id(int user_id) {
		this.user_id = user_id;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getCreated_by() {
		return created_by;
	}

	public void setCreated_by(String created_by) {
		this.created_by = created_by;
	}

	public String getModified_by() {
		return modified_by;
	}

	public void setModified_by(String modified_by) {
		this.modified_by = modified_by;
	}

	public Date getCreated_ae_time() {
		return created_ae_time;
	}

	public void setCreated_ae_time(Date created_ae_time) {
		this.created_ae_time = created_ae_time;
	}

	public Date getLast_modified_time() {
		return last_modified_time;
	}

	public void setLast_modified_time(Date last_modified_time) {
		this.last_modified_time = last_modified_time;
	}

	public User(String user_name) {
		super();
		this.user_name = user_name;
	}

	public User(int user_id, String password, String status, String created_by, String modified_by,
			Date created_ae_time, Date last_modified_time) {
		super();
		this.user_id = user_id;
		this.password = password;
		this.status = status;
		this.created_by = created_by;
		this.modified_by = modified_by;
		this.created_ae_time = created_ae_time;
		this.last_modified_time = last_modified_time;
	}

	public User() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "User [user_name=" + user_name + "]";
	}
	
	
}
