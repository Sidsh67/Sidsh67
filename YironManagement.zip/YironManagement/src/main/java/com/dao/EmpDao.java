package com.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.model.Emp;

@Component
public class EmpDao {
@Autowired
	private HibernateTemplate hibernateTemplate;
	//create
		@Transactional
		public void createEmp(Emp emp)
		{
			this.hibernateTemplate.save(emp);
		}
		
		//get all user
		public List<Emp> getEmp(){
			List<Emp> e=this.hibernateTemplate.loadAll(Emp.class);
			return e;
		}
		
		public Emp getDept(int eid)
		{
			return this.hibernateTemplate.load(Emp.class, eid);
		}
}
