package com.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.model.Department;

@Component
public class Dept_Dao {
@Autowired
private HibernateTemplate hibernateTemplate;
	
	//create
	@Transactional
	public void createDept(Department dept)
	{
		this.hibernateTemplate.save(dept);
	}
	
	//get all dept
	public List<Department> getDept(){
		List<Department> u=this.hibernateTemplate.loadAll(Department.class);
		return u;
	}
	
	public Department getDept(int uid)
	{
		return this.hibernateTemplate.load(Department.class, uid);
	}

}
