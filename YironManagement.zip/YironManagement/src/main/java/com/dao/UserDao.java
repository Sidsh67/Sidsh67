package com.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.model.User;

@Component
public class UserDao {
	@Autowired
	private HibernateTemplate hibernateTemplate;
	
	//create
	@Transactional
	public void createUser(User user)
	{
		this.hibernateTemplate.save(user);
	}
	
	//get all user
	public List<User> getUsers(){
		List<User> u=this.hibernateTemplate.loadAll(User.class);
		return u;
	}
	
	public User getUser(int uid)
	{
		return this.hibernateTemplate.load(User.class, uid);
	}

}
